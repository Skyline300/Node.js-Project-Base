const included = require("../../requires")


module.exports = {
    name:"channelcreate",
    event:true,
    async function(newChannel){
    }
}