const included = require("../../requires")


module.exports = {
    name:"guildMemberUpdate",
    event:true,
    async function(oldMember, newMember){
    }
}