const included = require("../../requires")


module.exports = {
    name:"memberadd",
    event:true,
    async function(newMember){
    }
}
