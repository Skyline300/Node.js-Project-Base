const included = require("../../requires")


module.exports = {
    name:"channelDelete",
    event:true,
    async function(oldChannel){
    }
}