const included = require("../../requires")


module.exports = {
    name:"onLeave",
    event:true,
    async function(oldGuild){
    }
}