const included = require("../../requires")


module.exports = {
    name:"onjoin",
    event:true,
    async function(newGuild){
    }
}