const included = require(`../../requires`)

/*

                    DO NOT FORGET TO ADD EVERY SINGLE EVENT ADDED HERE TO THE REMOVELISTENER ARRAY

*/

included.client.removeAllListeners("channelDelete")
included.client.removeAllListeners("guildMemberAdd")
included.client.removeAllListeners("guildCreate")
included.client.removeAllListeners("guildDelete")
included.client.removeAllListeners("channelCreate")
included.client.removeAllListeners("messageCreate")
included.client.removeAllListeners("messageReactionAdd")
included.client.removeAllListeners("guildMemberUpdate")

included.client.on("channelDelete", async oldchannel =>{
})

included.client.on("guildMemberAdd", async newMember => {
})

included.client.on("guildCreate", async newGuild => {
})

included.client.on("guildDelete", async oldGuild => {
})

included.client.on("channelCreate", async newChannel => {
})

included.client.on("messageCreate", async msg => {
    included.client.commands.get("onMessage").function(msg)
})

included.client.on("messageReactionAdd", async (reaction, user) => {
})

included.client.on("guildMemberUpdate", async (oldMember, newMember) => {
})

// included.client.on("error", (e) => console.error(e));
// included.client.on("warn", (e) => console.warn(e));
// included.client.on("debug", (e) => console.info(e));